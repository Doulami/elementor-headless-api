# Elementor Headless API Plugin

Expose Elementor-rendered WordPress pages and WooCommerce content as **clean HTML or JSON via REST API** — perfect for headless frontends like **Next.js**, **Vercel**, or **Netlify**.

---

## 🔌 REST API Endpoints

| Endpoint | Description |
|----------|-------------|
| `/headless-elementor/v1/page/{id}` | Fetch Elementor-rendered page by post ID |
| `/headless-elementor/v1/slug/{slug}` | Fetch Elementor-rendered page by slug |
| `/headless-elementor/v1/pages` | List all published pages/posts |
| `/headless-elementor/v1/status` | Plugin status info (Elementor version, cache, etc.) |
| `/headless-elementor/v1/woo/products` | List all WooCommerce products as JSON |
| `/headless-elementor/v1/woo/product/{id}` | Get Woo product by ID |
| `/headless-elementor/v1/woo/product/{slug}` | Get Woo product by slug |

---

## ⚙️ Query Parameters

| Query Flag | Purpose |
|------------|---------|
| `?nocache=1` | Bypass HTML cache for fresh render |
| `?debug=1` | Output debug info (cache used, timestamp) |
| `?format=json` | Return structured JSON instead of HTML |
| `?fields=...` | Select specific JSON fields (e.g. `?fields=id,slug,acf`) |
| `?token=XYZ` | Private preview access (for draft/protected posts) |

---

## 🧠 Admin Features

- ✅ Elementor-based rendering using `get_builder_content_for_display()`
- ✅ Clean HTML output (no theme headers/footers)
- ✅ JSON toggle for structured data
- ✅ Preview tokens (private/draft access via URL)
- ✅ Caching with transient API (12hr by default)
- ✅ Select2-powered template selectors (Header/Footer/Woo)
- ✅ Settings page in **WP Admin → Settings → Elementor Headless API**

---

## 💡 Template Injection

Use Elementor templates as **global headers or footers** injected into rendered pages.

Set these from the plugin settings:

- "Inject Header Template"
- "Inject Footer Template"

---

## 🧪 JSON Mode (`format=json`)

Enables API endpoints to return rich JSON, including:

- ACF fields (if enabled)
- `post_meta` data
- `terms` (taxonomy)
- Optional selective fields (`?fields=title,acf,meta`)

---

## 🔐 Token-Based Previews

Preview draft/private posts by generating secure tokens per post.

- Token meta saved per post
- Token expiry configurable
- Optional: restrict token access to **private posts only**

---

## 📦 Frontend SDK (JavaScript)

Path: `assets/js/headless-sdk/`

**Importable Functions:**
```js
import {
  fetchPageBySlug,
  fetchAllWooProducts,
  fetchWooProduct,
  fetchWooProductBySlug
} from './headless-sdk';
```

**Example Usage:**
```js
const page = await fetchPageBySlug('home', true); // ?nocache=1
const product = await fetchWooProduct(123);
const productBySlug = await fetchWooProductBySlug('tshirt-blue');
```

---

## 🚀 Deployment Notes

- Ideal for **Next.js**, **Astro**, **SvelteKit**, or static site builders
- Vercel/Netlify compatible
- Add loading indicators on `nocache=1` requests for better UX

---

## 📂 Folder Structure

```
elementor-headless-api/
├── elementor-headless-api.php
├── README.md (needs update)
├── readme.txt
│
├── admin/
│   └── admin-settings.php
│
├── assets/
│   └── js/
│       ├── headless-elementor-sdk.js         ← Old SDK
│       └── headless-sdk/                     ← Modularized SDK
│           ├── config.js
│           ├── index.js                      ← Central entry
│           ├── pages.js
│           ├── products.js
│           └── preview.js
│
├── includes/
│   ├── class-api-routes.php
│   ├── class-preview-tokens.php
│   ├── class-renderer.php
│   ├── class-settings.php
│   ├── class-template-suggestions-api.php
│   ├── class-utils.php
│   └── class-woocommerce-api-routes.php
│
└── templates/
    └── dynamic-placeholder.php
```

---

## 🛠️ Next Steps

- 🔐 Add JWT-secured previews
- 📊 Add usage metrics/logs for token links
- 📦 Expand SDK with update/create capabilities
