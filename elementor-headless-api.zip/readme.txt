=== Elementor Headless API ===
Converts Elementor pages to clean static HTML and serves them via REST API.

== Endpoint ==
GET /wp-json/headless-elementor/v1/page/{id}

== Future Features ==
- Slug support
- Dynamic block replacement
- HTML caching
- Admin settings page